/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Algortimos;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aldahir
 */
public class CalculadoraTest {
    
    public CalculadoraTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of verificaSintaxis method, of class Calculadora.
     */
    @Test
    public void testVerificaSintaxis() {
        System.out.println("verificaSintaxis");
        String expresion = "(4*5)-8/(6*_9)";
        boolean expResult = true;
        boolean result = Calculadora.verificaSintaxis(expresion);
        assertEquals(expResult, result);
    }

    /**
     * Test of esOperador method, of class Calculadora.
     */
    @Test
    public void testEsOperador() {
        System.out.println("esOperador");
        char c = '+';
        boolean expResult = true;
        boolean result = Calculadora.esOperador(c);
        assertEquals(expResult, result);
    }

    /**
     * Test of esOperando method, of class Calculadora.
     */
    @Test
    public void testEsOperando() {
        System.out.println("esOperando");
        char c = '8';
        boolean expResult = true;
        boolean result = Calculadora.esOperando(c);
        assertEquals(expResult, result);
    }

    /**
     * Test of hacerArreglo method, of class Calculadora.
     */
    @Test
    public void testHacerArreglo() {
        System.out.println("hacerArreglo");
        String exp = "5*2-1";
        String[] expResult ={"5","*","2","-","1",null};
        String[] result = Calculadora.hacerArreglo(exp);
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of checarJerarquia method, of class Calculadora.
     */
    @Test
    public void testChecarJerarquia() {
        System.out.println("checarJerarquia");
        char c = '*';
        int expResult = 2;
        int result = Calculadora.checarJerarquia(c);
        assertEquals(expResult, result);
    }

    /**
     * Test of notacionPostfija method, of class Calculadora.
     */
    @Test
    public void testNotacionPostfija() {
        System.out.println("notacionPostfija");
        String[] arreExp = {"5","*","2","-","1",null};;
        String[] expResult = {"5","2","*","1","-",null};
        String[] result = Calculadora.notacionPostfija(arreExp);
        assertArrayEquals(expResult, result);
    }

    /**
     * Test of esNumero method, of class Calculadora.
     */
    @Test
    public void testEsNumero() {
        System.out.println("esNumero");
        String cadena = "8";
        boolean expResult = true;
        boolean result = Calculadora.esNumero(cadena);
        assertEquals(expResult, result);
    }

    /**
     * Test of evaluaPosfija method, of class Calculadora.
     */
    @Test
    public void testEvaluaPosfija() {
        System.out.println("evaluaPosfija");
        String[] arr = {"5","2","*","1","-",null};
        double expResult = 9.0;
        double result = Calculadora.evaluaPosfija(arr);
        assertEquals(expResult, result, 0.0);
    }

    /**
     * Test of calcula method, of class Calculadora.
     */
    @Test
    public void testCalcula() {
        System.out.println("calcula");
        String expresion = "5*5+2";
        double expResult = 27.0;
        double result = Calculadora.calcula(expresion);
        assertEquals(expResult, result, 0.0);
    }
    
}
